<!DOCTYPE html>
<html lang="zxx">

	<head>
		<title>abacus faq</title>
		<!-- Meta tag Keywords -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta charset="UTF-8" />
		<meta name="keywords" content="Edulearn Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design"
		/>

		<?php include('includes/head.php');?>
	</head>

	<body>
	<!-- header -->
	<?php include('includes/header1.php');?>
	<!-- //header -->

	<!-- banner -->
	<?php include('includes/navbar.php');?>
	<!-- breadcrumb -->
	<nav aria-label="breadcrumb">
		<ol class="breadcrumb">
			<li class="breadcrumb-item">
				<a href="index.php">Home</a>
			</li>
			<li class="breadcrumb-item active" aria-current="page">FAQ's</li>
		</ol>
	</nav>
<!--// breadcrumb -->
<!-- //banner -->

	<!-- faqs -->
	<div class="faq-w3l py-5">
		<div class="container py-xl-5 py-lg-3">
			<h3 class="title text-capitalize font-weight-light text-dark text-center mb-5">faqs
				<span class="font-weight-bold"></span>
			</h3>
			<div class="faq-w3agile">
			<ul class="faq pl-sm-4 pl-3">
				<li class="item1 mt-sm-4 mt-3 pl-2">
					<a href="#" title="click here"> How are the franchise appointed by Abacus Academy?</a>
					<ul>
						<li class="subitem1 mt-3">
							<p> 
								The Franchise of ABACUS ACADEMY Abacus is given to the person having the passion to excel in children education, has a go-getter attitude, and is willing to do the business for the long-term. The most eligible is a person with excellent entrepreneurial skills and is willing to adapt the technology and system best suited for the business.
							</p>
						</li>
					</ul>
				</li>
				<li class="item2 mt-sm-4 mt-3 pl-2">
					<a href="#" title="click here"> What is Franchise fee? / What is the investment required to take up a franchise?
					</a>
					<ul>
					<li class="subitem1 mt-3">
						<p> The initial investment may vary as per the area/country chosen for setting up a franchisee center. Please fill the below inquiry form, our team will get back to you soon with all the required details specific to your area. Franchisee Inquiry.</p>
					</li>
				</ul>
			</li>
			<li class="item3 mt-sm-4 mt-3 pl-2">
				<a href="#" title="click here">
				What is the initial term of the franchise agreement?
				</a>
				<ul>
					<li class="subitem1 mt-3">
						<p>The franchisee is given for 5 years initially, after which it can be renewed.
						</p>
					</li>
				</ul>
			</li>
			<li class="item4 mt-sm-4 mt-3 pl-2">
				<a href="#" title="click here">What support and services will I get from the company end, If I take up a franchise?</a>
				<ul>
					<li class="subitem1 mt-3">
						<p>1) support & services begins from setting up your centre and never ends. After setting up your centre, our Training & Post Franchisee Operation department helps you to start and grow your business.The exclusive Support & Services provided by us are:
						<br>
						2) a. Franchisee Kit: We will provide this to enable you to initially set-up your franchisee centre.
						<br>
						3) b. Training: Training is a crucial element in the success of any business and, mode of training is an important factor too. We at ABACUS ACADEMY understand this. We provide one to one training, online training through Apps, Software and DVDs, depending upon the choice of trainee. Apart from Product Training/Academic Training, we also provide Marketing & Counselling Training and ERP Training with ongoing Refresher Trainings.
						<br>
						4) c. Training Kit: It is provided to facilitate the smooth training conduction.<br>
						5) d. ERP Franchise Panel: We will provide you an exclusive Franchisee ERP Panel, which enables you to manage your entire business process from maintaining centre, trainer and student records, to placing order and updating stocks. It also helps in training, conducting online exam & certification. Basically, it is a tool that helps in maintaining a smooth liaison between you and the company for all your required services.</p>
					</li>
				</ul>
			</li>
			<li class="item5 mt-sm-4 mt-3 pl-2">
				<a href="#" title="click here"> I am a house wife having no previous experience, can I own a franchise?</a>
				<ul>
					<li class="subitem1 mt-3">
						<p>If you have a passion for teaching children and are financially able to start your education center and willing to put in the hard work to make it successful than you can start the ABACUS ACADEMY Franchisee Center. Our support team will help you to achieve your objectives.</p>
					</li>
				</ul>
			</li>
			<li class="item6 mt-sm-4 mt-3 pl-2">
				<a href="#" title="click here"> Do I have to be a math graduate to become a trainer?</a>
				<ul>
					<li class="subitem1 mt-3">
						<p>You need not be a Math graduate. Your basic knowledge of Math will help you in becoming a trainer, your ability of communication and teaching skills will be more important for your success.</p>
					</li>
				</ul>
			</li>
			<li class="item7 mt-sm-4 mt-3 pl-2">
				<a href="#" title="click here"> How would you provide training?</a>
				<ul>
					<li class="subitem1 mt-3">
						<p>We can provide training through online and offline modes depending upon the requirement/choice of trainee. We have an option of one-to-one training at Head Office. We can also provide, Online training through DVDs’, Mobile app and Skype and our 24*7 Live teacher called Virtual Abacus also available for solution of all you customize Abacus related problems.</p>
					</li>
				</ul>
			</li>
			<li class="item8 mt-sm-4 mt-3 pl-2">
				<a href="#" title="click here"> What is Master Franchise?</a>
				<ul>
					<li class="subitem1 mt-3">
						<p>A Master Franchisee is a franchising contract with sub franchising rights in specified territory between company and a person. The Master Franchisee will be responsible for recruiting, training and providing support and services to the unit franchisees of their territory.
						</p>
					</li>
				</ul>
			</li>
			<li class="item9 mt-sm-4 mt-3 pl-2">
				<a href="#" title="click here"> What is the process for becoming a franchise?</a>
				<ul>
					<li class="subitem1 mt-3">
						<p>Lorem ipsum dolor sit amet At vero eos et Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod consectetuer adipiscing elit, sed diam nonummy nibh euismod accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident.</p>
					</li>
				</ul>
			</li>
			<li class="item10 mt-sm-4 mt-3 pl-2">
				<a href="#" title="click here"> Why should I take the Abacus Academy’s franchise?</a>
				<ul>
					<li class="subitem1 mt-3">
						<p>Few salient features make ABACUS ACADEMY unique from other Abacus companies. Justified Franchisee Fee, Modern Trainings & Game-Based teaching methodology, Research-Based classroom conduction methods, sensational student’s results and remarkable ‘Support & Services’ beyond customer’s satisfaction, which makes ABACUS ACADEMY ‘The Peerless leader’. Still, taking up the ABACUS ACADEMY  Franchisee will be your decision.</p>
					</li>
				</ul>
			</li>
			<li class="item10 mt-sm-4 mt-3 pl-2">
				<a href="#" title="click here">I currently own an abacus classes/coaching Centre. Is it possible to convert it into an abacus classes of Abacus Academy?</a>
				<ul>
					<li class="subitem1 mt-3">
						<p>Yes, you can convert your existing Centre in ABACUS ACADEMY. For details, please fill Franchisee Inquiry Form. Our team shall soon contact you.</p>
					</li>
				</ul>
			</li>
			<li class="item10 mt-sm-4 mt-3 pl-2">
				<a href="#" title="click here">If I recruit new staff during the franchise period can my new staff get the training again?</a>
				<ul>
					<li class="subitem1 mt-3">
						<p>Training at Head Office is always free for ABACUS ACADEMY Franchisee Partners. In case of distance issue or unavailability of time, you may opt to online training option.</p>
					</li>
				</ul>
			</li>
			<li class="item10 mt-sm-4 mt-3 pl-2">
				<a href="#" title="click here"> How can Abacus Academy help children and parents?</a>
				<ul>
					<li class="subitem1 mt-3">
						<p>ABACUS ACADEMY training imbibes the following qualities in the students like Proficiency in Math, an excellent Recall due to improved Photographic Memory, Visualization Abilities and augmented listening ability. The entire qualities exhibit in the form of a confident child. This ensures a success in overall academics and later in life too. This obviously removes parent’s worries about the child’s future.
						</p>
					</li>
				</ul>
			</li>
		</ul>
	</div>
</div>
</div>


	<!-- footer -->
	<?php include('includes/footer.php');?>
	<!-- //footer -->


	<!-- Js files -->
	<!-- JavaScript -->
	 <?php include('includes/script.php');?>	

	<!-- //Js files -->


</body>

</html>