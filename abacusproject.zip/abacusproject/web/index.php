<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>
		SKABACUS Home page
	</title>

		<meta name="viewport" content="width=device-width, initial-scale=1">
			<meta charset="UTF-8" />
			<meta name="keywords" content="Edulearn Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design"
			/>
<!-- banner slider -->
			<script src="js/slider.js"></script>
<!-- //banner slider -->

	<?php include('includes/head.php');?>
		<style type="text/css">
		/*for read more*/
        #more {
          display: none;
        }
	</style>
</head>
<body>
	<?php include('includes/header1.php');?>
		<!-- banner -->
	<div class="banner-agile">
		<ul class="slider">
			<li class="active">
				<div class="banner-w3ls-1">
				</div>
			</li>
			<li>
				<div class="banner-w3ls-2">
				</div>
			</li>
			<li>
				<div class="banner-w3ls-3">
				</div>
			</li>
			<li>
				<div class="banner-w3ls-4">
				</div>
			</li>
			<li class="prev">
				<div class="banner-w3ls-5">
				</div>
			</li>
		</ul>
		<ul class="pager">
			<li data-index="0" class="active"></li>
			<li data-index="1"></li>
			<li data-index="2"></li>
			<li data-index="3"></li>
			<li data-index="4"></li>
		</ul>
		<div class="banner-text-posi-w3ls">
			<div class="banner-text-whtree">
				<h3 class="text-capitalize text-white p-4">Your Child's bright future
					<b>is our mission!</b>
				</h3>
				<p class="px-4 py-3 text-dark">India's First Company In Child Education...</p>
				<a href="about.php" class="button-agiles text-capitalize text-white mt-sm-5 mt-4">read more</a>
			</div>
		</div>

		<!-- navigation -->
		<div class="navigation-w3ls">
			<nav class="navbar navbar-expand-lg navbar-light bg-light sticky-nav">
				<button class="navbar-toggler mx-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
				 aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse text-center" id="navbarSupportedContent">
					<ul class="navbar-nav justify-content-center">
						<li class="nav-item active">
							<a class="nav-link text-white" href="index.php">Home
								<span class="sr-only">(current)</span>
							</a>
						</li>
						<li class="nav-item">
							<a class="nav-link text-white" href="about.php">About Us</a>
						</li>
						<!-- <li class="nav-item dropdown">
							<a class="nav-link dropdown-toggle text-white" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								Courses
							</a>
							<div class="dropdown-menu">
								<a class="dropdown-item" href="courses.php">Courses</a> -->
								<!-- <a class="dropdown-item" href="communication.php">Communication</a>
								<a class="dropdown-item" href="business.php">Business</a>
								<a class="dropdown-item" href="software.php">Software</a>
								<a class="dropdown-item" href="social_media.php">Social Media</a>
								<a class="dropdown-item" href="photography.php">Photography</a>
								<a class="dropdown-item" href="course_details.php">Course Details</a>
								<div class="dropdown-divider"></div>
								<a class="dropdown-item" href="form.php">Apply Now</a> -->
							<!-- </div>
						</li> -->
						<!-- <li class="nav-item dropdown">
							<a class="nav-link dropdown-toggle text-white" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								Pages
							</a>
							<div class="dropdown-menu">
								<a class="dropdown-item" href="about.php">Instructors</a>
								<a class="dropdown-item" href="index.php">What We Do</a>
								<a class="dropdown-item" href="login.php">Login</a>
								<a class="dropdown-item" href="register.php">Register</a>
								<a class="dropdown-item" href="404.php">404 Page</a>
								<a class="dropdown-item" href="coming_soon.php">Coming Soon</a>
								<a class="dropdown-item" href="form.php">Admission Form</a>
								<a class="dropdown-item" href="faq.php">Faq</a>
							</div>
						</li> -->
						<li class="nav-item">
							<a class="nav-link text-white" href="courses.php">Courses</a>
						</li>
						<li class="nav-item">
							<a class="nav-link text-white" href="FAQ.php">FAQ</a>
						</li>
						<li class="nav-item">
							<a class="nav-link text-white" href="blog.php">Blog</a>
						</li>
						<!-- <li class=nav-item">
							<a class="nav-link text-white" href=""blog.php">Blog</a>
						</li> -->
						<li class="nav-item">
							<a class="nav-link text-white" href="gallery.php">Gallery</a>
						</li>
						<li class="nav-item">
							<a class="nav-link text-white" href="contact.php">Contact Us</a>
						</li>
					</ul>
				</div>
			</nav>
		</div>
		<!-- //navigation -->
	</div>
	<!-- //banner -->


		<!-- about -->
	<div class="about">
		<div class="container py-xl-5 py-lg-3">
			<h3 class="title text-capitalize font-weight-light text-dark text-center mb-5">Welcome to
				<span class="font-weight-bold">SK's ABACUS</span>
			</h3>
			<div class="row pt-md-4">
				<div class="col-lg-6 about_right">
					<h3 class="text-capitalize text-right font-weight-light font-italic">interface friendly learning at
						<span class="font-weight-bold">Abacus Academy</span>
					</h3>
					<p class="text-justify my-4 pr-4 border-right">
						ABACUS ACADEMY Started in 2009, An ISO 9001:2015 certified company a unit of S.K. Academy, is continuously growing in the market. We are manufacturer, supplier and exporter of Abacus and Training Courses. Our wide range of product includes Abacus Books & Abacus Study Material. Also, we are the leading service provider of Trainings and Franchise and Montessori Teacher Training Courses.
						<span id="dots">...</span>
						<span id="more">
						All these products and services are widely demanded across the world to teach the children in effective way. ABACUS ACADEMY Happy to introduce you to all to our interactive Online abacus and Vedic math’s learning app. It is incorporated with one of its kind of features, which makes the abacus learning process more interesting and enjoyable. We introducing abacus and Vedic math’s learning through online with SKSMS android app. With the guidance of Mr. Jagannath Yadav we are sharply growing in the national and international market and offering best study material to teachers and parents at nominal charges.
						Abacus training is universally accepted 'Complete Brain Development program which activates both Left and Right Hemispheres of a child’s brain. Abacus Academies abacus classes are not only about Mental Math or improving Mental Arithmetic Calculation, but also helps to excel in all the subjects. Our Abacus Training Methodology makes a child learn Math by Play & Learn method. It is the amalgamation of ancient and modern technology, which gives an edge to Abacus Academy course over other's Abacus Program. Abacus Academy promotes whole brain development that strengthens The Core Skills like Memory, Concentration, Creativity and Problem Solving, that instil greater confidence & success in overall academics and in life.
					</span>
					</p>
					<button onclick="myFunction()" id="myBtn" class="btn" style=" background-color: #42a5f5; color: white;">
								Read more
              		</button>

					<div class="about_left-list pt-2">
						<h6 class="mb-lg-3 mb-2 font-weight-bold text-dark">Our Benefits</h6>
						<ul class="list-unstyled">
							<li class="mb-2">
								<i class="fas fa-check mr-3"></i>
								Students develop a great sense towards numbers
							</li>
							<li class="mb-2">
								<i class="fas fa-check mr-3"></i>
								This increases their speed  
							</li>
							<li>
								<i class="fas fa-check mr-3"></i>
								Also increase accuracy dramatically
							</li>
							<li class="mb-2">
								<i class="fas fa-check mr-3"></i>
								Activates right brain & trains to face competition.
								 
							</li>
							<li>
								<i class="fas fa-check mr-3"></i>
								Increases comprehension & imagination.
							</li>
							<li>
								<i class="fas fa-check mr-3"></i>
								endurance, learning & writing skills
							</li>
							<li class="mb-2">
								<i class="fas fa-check mr-3"></i>
								Boosts their memory power
							</li>
							<li class="mb-2">
								<i class="fas fa-check mr-3"></i>Promotes concentration of children
							</li>
							<li class="mb-2">
								<i class="fas fa-check mr-3"></i>
								Enhances mathematical logic 
							</li>
						</ul>
					</div>
				</div>
				<div class="col-lg-6 left-img-agikes mt-lg-0 mt-sm-4 mt-3 text-right">
					<img src="images/ab.jpg" alt="" class="img-fluid" />

					<div class="about-bottom text-center p-sm-5 p-4">
						<ul>
							<li>
								<h5>60+</h5>
								<p class="text-dark font-weight-bold">Teachers</p>
							</li>
							<li>
								<h5>2000+</h5>
								<p class="text-dark font-weight-bold">Students</p>
							</li>
							<li>
								<h5>80+</h5>
								<p class="text-dark font-weight-bold">Courses</p>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	<!-- //about -->

				<!-- what we do -->
<div class="why-choose-agile py-5">
	<div class="container py-xl-5 py-lg-3">
		<h3 class="title text-capitalize font-weight-light text-white text-center mb-5">what we
		<span class="font-weight-bold">do</span>
		</h3>
		<div id="demo" class="carousel slide" data-ride="carousel">
 <!-- Indicators -->
		 <ul class="carousel-indicators" style="top: 286px;">
		   <li data-target="#demo" data-slide-to="0" class="active"></li>
		   <li data-target="#demo" data-slide-to="1"></li>
		   <li data-target="#demo" data-slide-to="2"></li>
		   <li data-target="#demo" data-slide-to="3"></li>
		   <li data-target="#demo" data-slide-to="4"></li>
		   <li data-target="#demo" data-slide-to="5"></li>
		   <li data-target="#demo" data-slide-to="6"></li>
		 </ul>

<!-- The slideshow -->
		<div class="carousel-inner" style="text-align: center;">
		   <div class="carousel-item active">
		     	<img src="images/i1.jpg" class="rounded-circle"  style="width: 215px;height: 200px;">
	   			<h1 style="color: white;">Welcome to SK's Abacus Academy</h1>
	   			<p style="color: white;">It is Central India's first company in child education givimmg best advance skill development program.</p>
   			</div>
   			<div class="carousel-item">
       			<img src="images/i2.jpg" class="rounded-circle"  style="width: 215px;height: 200px;">
   				<h1 style="color: white;">REINFORCE YOUR CHILD'S...LISTENING AND OBSERVATION </h1>
   				<p style="color: white;">To Provide Them A Key To Learn,Understand And Perform For Excellence Enroll.</p>  
   			</div>
   			<div class="carousel-item">
       			<img src="images/i3.jpg" class="rounded-circle"  style="width: 215px;height: 200px;">
			   <h1 style="color: white;">BOOST YOUR CHILD’S…MEMORY</h1>
			   <p style="color: white;">To Excel In Academic And Life, Enroll…..</p>
			</div>
		   <div class="carousel-item">
		       <img src="images/i4.jpg" class="rounded-circle"  style="width: 215px;height: 200px;">
		   		<h1 style="color: white;">IGNITE YOUR CHILD’S……CREATIVITY</h1>
		   		<p style="color: white;"></p>
		   </div>
		   <div class="carousel-item">
		       <img src="images/i5.jpg" class="rounded-circle"  style="width: 215px;height: 200px;">
			   <h1 style="color: white;">RAISE YOUR CHILD’S……CONCENTRATION LEVEL</h1>
			   <p style="color: white;">To Step Up Your Child's Overall Academic Performance, Enroll Your Child At Abacus Academy</p>
		   </div>
		   <div class="carousel-item">
		       <img src="images/i6.jpg" class="rounded-circle" style="width: 215px;height: 200px;">
		   		<h1 style="color: white;">GROOM YOUR CHILD’S…SELF CONFIDENCE</h1>
		   		<p style="color: white;">By Improving Speed And Accuracy In Mental Arithmetic.Enroll….</p>
		   </div>
		   <div class="carousel-item">
		       <img src="images/i7.jpg" class="rounded-circle"  style="width: 215px;height: 200px;">
			   <h1 style="color: white;">DEVELOPS YOUR CHILD’S IMAGINATION AND VISUALIZATION</h1>
			   <p style="color: white;">To Train The Use Of Virtual Abacus In Solving Math Problems</p>
		   </div>
		   <div class="carousel-item">
		       <img src="images/ap-3.jpg" class="rounded-circle"  style="width: 215px;height: 200px;">
   				<h1 style="color: white;">AMPLIFY YOUR CHILD’S RIGHT AND LEFT BRAIN</h1>
   				<p style="color: white;">Augment The Whole Brain Abilities At Abacus Academy</p>
   			</div>

   <!-- Left and right controls -->
  			<a class="carousel-control-prev" href="#demo" data-slide="prev">
               <span class="carousel-control-prev-icon" style="background-color: red;"></span>
            </a>
            <a class="carousel-control-next" href="#demo" data-slide="next">
               <span class="carousel-control-next-icon" style="background-color: red;"></span>
            </a>
   		</div>
	</div>
</div>
</div>
	<!-- //what we do -->

		<!-- course-->
		<div class="classes py-5">
			<div class="container py-xl-5 py-lg-3">
				<h3 class="title text-capitalize font-weight-light text-dark text-center mb-sm-5 mb-4">choose your
					<span class="font-weight-bold">course</span>
				</h3>
				<div class="row pt-4">
					<div class="col-lg-3 col-news-top text-center">
						<!-- Left to right -->
						<!-- normal -->
						<div class="ih-item circle effect16 left_to_right mx-auto">
							<a href="courses.php">
								<div class="img">
									<img src="images/c1.jpg" alt="img" class="img-fluid rounded-circle">
								</div>
								<div class="info">
									<h3 class="text-capitalize text-white">Vedic Maths</h3>
									<p>Description goes here</p>
								</div>
							</a>
						</div>
						<h6 class="small-heading text-capitalize text-center mt-4">
							<a href="language.php" class="text-dark">Vedic Maths
								<i class="fas fa-long-arrow-alt-right ml-1"></i>
							</a>
						</h6>
						<!-- end normal -->
						<!-- end Left to right -->
					</div>
					<div class="col-lg-3 col-news-top text-center my-lg-0 my-sm-5 my-4">
						<!-- Left to right -->
						<!-- normal -->
						<div class="ih-item circle effect16 left_to_right mx-auto">
							<a href="courses.php">
								<div class="img">
									<img src="images/c2.jpg" alt="img" class="img-fluid rounded-circle">
								</div>
								<div class="info">
									<h3 class="text-capitalize text-white">Hand Writing</h3>
									<p>Description goes here</p>
								</div>
							</a>
						</div>
						<h6 class="small-heading text-capitalize text-center mt-4">
							<a href="courses.php" class="text-dark">Hand Writing
								<i class="fas fa-long-arrow-alt-right ml-1"></i>
							</a>
						</h6>
						<!-- end normal -->
						<!-- end Left to right -->
					</div>
					<div class="col-lg-3 col-news-top text-center">
						<!-- Left to right -->
						<!-- normal -->
						<div class="ih-item circle effect16 left_to_right mx-auto">
							<a href="courses.php">
								<div class="img">
									<img src="images/c3.jpg" alt="img" class="img-fluid rounded-circle">
								</div>
								<div class="info">
									<h3 class="text-capitalize text-white">Abacus At School</h3>
									<p>Description goes here</p>
								</div>
							</a>
						</div>
						<h6 class="small-heading text-capitalize text-center mt-4">
							<a href="courses.php" class="text-dark">Abacus
								<i class="fas fa-long-arrow-alt-right ml-1"></i>
							</a>
						</h6>
						<!-- end normal -->
						<!-- end Left to right -->
					</div>
				<!-- </div> -->
				<div class="col-lg-3 col-news-top text-center">
						<!-- Left to right -->
						<!-- normal -->
					<div class="ih-item circle effect16 left_to_right mx-auto">
						<a href="courses.php">
							<div class="img">
								<img src="images/c3.jpg" alt="img" class="img-fluid rounded-circle">
							</div>
							<div class="info">
								<h3 class="text-capitalize text-white">Montessori Training</h3>
								<p>Description goes here</p>
							</div>
						</a>
					</div>
					<h6 class="small-heading text-capitalize text-center mt-4">
						<a href="software.php" class="text-dark">Montessori
							<i class="fas fa-long-arrow-alt-right ml-1"></i>
						</a>
					</h6>
						<!-- end normal -->
						<!-- end Left to right -->
				</div>
			</div>
		</div>
	</div>
</div>
		<!-- //course -->

		<!-- for read more button -->
		  <script>
		  function myFunction() {
		  var dots = document.getElementById("dots");
		  var moreText = document.getElementById("more");
		  var btnText = document.getElementById("myBtn");

		  if (dots.style.display === "none") {
		    dots.style.display = "inline";
		    btnText.innerHTML = "Read more"; 
		    moreText.style.display = "none";
		  } else {
		    dots.style.display = "none";
		    btnText.innerHTML = "Read less"; 
		    moreText.style.display = "inline";
		  }
		}
		</script>

	<?php include('includes/script.php')?>

	<?php include('includes/footer.php')?>
</body>
</html>