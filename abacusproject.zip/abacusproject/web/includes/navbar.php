
	<!-- banner -->
	<div class="banner-agile-2">
		<!-- navigation -->
		<div class="navigation-w3ls">
			<nav class="navbar navbar-expand-lg navbar-light bg-light sticky-nav">
				<button class="navbar-toggler mx-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
				 aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse text-center" id="navbarSupportedContent">
					<ul class="navbar-nav justify-content-center">
						<li class="nav-item">
							<a class="nav-link text-white" href="index.php">Home
								<span class="sr-only">(current)</span>
							</a>
						</li>
						<li class="nav-item">
							<a class="nav-link text-white" href="about.php">About Us</a>
						</li>
						<li class="nav-item">
							<a class="nav-link text-white" href="courses.php">Courses</a>
						</li>
						<!-- <li class="nav-item dropdown">
							<a class="nav-link dropdown-toggle text-white" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								Courses
							</a>
							<div class="dropdown-menu">
								<a class="dropdown-item" href="courses.php">Our Courses</a> -->
								<!-- <a class="dropdown-item" href="communication.php">Communication</a>
								<a class="dropdown-item" href="business.php">Business</a>
								<a class="dropdown-item" href="software.php">Software</a>
								<a class="dropdown-item" href="social_media.php">Social Media</a>
								<a class="dropdown-item" href="photography.php">Photography</a>
								<a class="dropdown-item" href="course_details.php">Course Details</a>
								<div class="dropdown-divider"></div>
								<a class="dropdown-item" href="form.php">Apply Now</a> -->
<!-- 							</div>
						</li> -->

					<!-- 	<li class="nav-item dropdown">
							<a class="nav-link dropdown-toggle text-white" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								Pages
							</a>
							<div class="dropdown-menu">
								<a class="dropdown-item" href="about.php">Instructors</a>
								<a class="dropdown-item" href="index.php">What We Do</a>
								<a class="dropdown-item" href="login.php">Login</a>
								<a class="dropdown-item" href="register.php">Register</a>
								<a class="dropdown-item" href="404.php">404 Page</a>
								<a class="dropdown-item" href="coming_soon.php">Coming Soon</a>
								<a class="dropdown-item" href="form.php">Admission Form</a>
								<a class="dropdown-item" href="faq.php">Faq</a>
							</div>
						</li> -->
						<li class="nav-item">
							<a class="nav-link text-white" href="faq.php">FAQ</a>
						</li>
						<li class="nav-item">
							<a class="nav-link text-white" href="blog.php">Blog</a>
						</li>
						<li class="nav-item">
							<a class="nav-link text-white" href="gallery.php">Gallery</a>
						</li>
						<li class="nav-item active">
							<a class="nav-link text-white" href="contact.php">Contact Us</a>
						</li>
					</ul>
				</div>
			</nav>
		</div>
		<!-- //navigation -->
	</div>