<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>abacus About</title>
	<!-- Meta tag Keywords -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta charset="UTF-8" />
	<meta name="keywords" content="Edulearn Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design"
	/>

	<?php include('includes/head.php');?>
	<style type="text/css">
		/*for read more*/
        #more {
          display: none;
        }
	</style>
</head>

<body>
	<!-- header -->
	<?php include('includes/header1.php');?>
	<!-- //header -->

	<!-- banner -->
	<?php include('includes/navbar.php');?>
	<!-- breadcrumb -->
	<nav aria-label="breadcrumb">
		<ol class="breadcrumb">
			<li class="breadcrumb-item">
				<a href="index.html">Home</a>
			</li>
			<li class="breadcrumb-item active" aria-current="page">About Us</li>
		</ol>
	</nav>
<!--// breadcrumb -->
<!-- //banner -->
<!-- about section -->
	<div class="about-page py-5">
		<div class="container py-xl-5 py-lg-3">
			<h3 class="title text-capitalize font-weight-light text-dark text-center mb-5">about
				<span class="font-weight-bold">us</span>
			</h3>
			<div class="row about-head-wthree">
				<div class="col-lg-6 left-abw3ls">
					<img src="images/ap-1.jpg" alt="" class="img-fluid">
				</div>
				<div class="col-lg-6 right-abw3ls mt-lg-0 mt-sm-5 mt-4">
					<h4 class="font-italic border-bottom text-center font-weight-bold pb-3 mb-4">
						Our History
					</h4>
					<p class="text-justify">
						SK Abacus is a brain development program based on mental arithmetic concept. SK Abacus is a method of mental calculation using beads at highly accelerated speed. This abacus training will help the child to improve the ability to do calculations as fast as calculator. This abacus program consists of 8 levels. Each level lasts for 3 months. The training sessions are conducted once in a Week for two hours. The name Abacus is derives from the Greek word 
						<b>"ABAX"</b> meaning table or board covered with dust. It is generally assumed that the origin of abacus is in Middle East in The Middle Age Period. 
						<span id="dots">...</span>
						<span id="more">
						An Abacus is an ancient computing methodology developed in CHINA where students learn to solve Arithmetic problems like Addition, Subtraction, Multiplication, Division, Lcm, Gcd, Decimals, Percentages, Square root, Cube roots, negative numbers using a simple instrument called Abacus.
						<br>
						Exciting Photographic Memory will develop in students.
						<br>
						Like any other organ of human body, our brain too needs regular exercising to keep it fit and sharp. But how do we exercise our brain?? Mathematics provides the ideal exercise for our brain. Mathematics is the logical application of mind to tackle a particular problem. More time spent with mathematics would invariably result in a well exercised and a sharper brain. This is simply the reason why a child strong at mathematics is able to tackle other subjects with relative ease.
					</span>
					</p>
					<button onclick="myFunction()" id="myBtn" class="btn" style=" background-color: #42a5f5; color: white;">
								Read more
              		</button>
				</div>
			</div>
		</div>
	</div>
	<section>
		<div class="container">
			<div class="row">
				<div class="col-6 col-lg-6 col-md-6">
					<h5 style="color: #42a5f5;">BENEFITS OF SK-ABACUS:
					</h5><br>
           			<ul class="text-justify" style="padding-left: 15px;">
             			<li style="font-family: 'Open Sans', sans-serif;font-size: 15px;letter-spacing: 1px;line-height: 1.9;color: #999;">
             				<i class="ri-check-double-line">
             				</i> 
             				Improve concentration
             			</li>
             			<li style="font-family: 'Open Sans', sans-serif;font-size: 15px;letter-spacing: 1px;line-height: 1.9;color: #999;">
             				<i class="ri-check-double-line"></i> Improve listening skills
             			</li>
             			<li style="font-family: 'Open Sans', sans-serif;font-size: 15px;letter-spacing: 1px;line-height: 1.9;color: #999;">
             				<i class="ri-check-double-line"></i>	Sharper observation
             			</li>
             			<li style="font-family: 'Open Sans', sans-serif;font-size: 15px;letter-spacing: 1px;line-height: 1.9;color: #999;"><i class="ri-check-double-line"></i>improve self confidence
             			</li>
             			<li style="font-family: 'Open Sans', sans-serif;font-size: 15px;letter-spacing: 1px;line-height: 1.9;color: #999;"><i class="ri-check-double-line"></i>better calculations
             			</li>
             			<li style="font-family: 'Open Sans', sans-serif;font-size: 15px;letter-spacing: 1px;line-height: 1.9;color: #999;"><i class="ri-check-double-line"></i>better creativity and
             			</li>
             			<li style="font-family: 'Open Sans', sans-serif;font-size: 15px;letter-spacing: 1px;line-height: 1.9;color: #999;"><i class="ri-check-double-line"></i> imaginative skills
             			</li>
           			</ul>
        		</div>
				<div class="col-6 col-lg-6 col-md-6">
					<h5 style="color: #42a5f5;">
						FUN WITH MATHEMATICS :
					</h5><br>
          			<p>
          				But most children fear mathematics and often try to escape from the complexities of problem solving. This is where Abacus comes to aid. Abacus develops speed and accuracy in mathematics using very basic methods. This naturally develops aptitude and liking for Mathematics within a very short period.
						An early mechanical calculator whose design has evolved through the centuries, with two styles in use today. Both the Chinese and the Japanese styles consist of a frame with a crossbeam. They may be made from many different materials, such as wood or brass. Rods or wires carrying sliding beads extend vertically through the crossbeam. The Chinese suan pan has two beads above the beam on each rod and five beads below. Each rod of the Japanese soroban carries one bead above and four below.
					</p>
				</div>
			</div>
		</div>
	</section>
<!-- //history -->

<!-- mission -->
	<div class="about-page-2 py-5">
		<div class="container-fluid py-xl-5 py-lg-3">
			<div class="row about-head-wthree-2">
				<div class="col-lg-4 left-abw3ls text-lg-left text-center">
					<img src="/images/img1(1).jpg" alt="" class="img-fluid">
				</div>
				<div class="col-lg-4 right-abw3ls my-lg-0 my-sm-5 my-4">
					<h4 class="font-italic border-bottom text-center font-weight-bold pb-3 mb-4">
						Our Mission
					</h4>
					<p>To boost the child's moral fiber. We target at training the children to use their extreme ability.</p><br>
					<h4 class="font-italic border-bottom text-center font-weight-bold">Our Vision</h4>
					<p> Our vision is to make every child in India and the world in the relevant age group of 6-14 yrs realize the benefits of Abacus & Mental Arithmetic education.<br>
					</p>
				</div>

				<div class="col-lg-4 left-abw3ls text-lg-left text-center">
					<img src="/images/img3.jpeg" alt="" class="img-fluid" style="height: 284px;">
				</div>
			</div>
		</div>
	</div>

	<!-- footer -->
	<?php include('includes/footer.php');?>
	<!-- //footer -->

<!-- for read more button -->
  <script>
  function myFunction() {
  var dots = document.getElementById("dots");
  var moreText = document.getElementById("more");
  var btnText = document.getElementById("myBtn");

  if (dots.style.display === "none") {
    dots.style.display = "inline";
    btnText.innerHTML = "Read more"; 
    moreText.style.display = "none";
  } else {
    dots.style.display = "none";
    btnText.innerHTML = "Read less"; 
    moreText.style.display = "inline";
  }
}
</script>
	<!-- Js files -->
	<!-- JavaScript -->
	 <?php include('includes/script.php');?>	

	<!-- //Js files -->


</body>

</html>