<!DOCTYPE html>
<html lang="zxx">

	<head>
		<title>abacus courses</title>
		<!-- Meta tag Keywords -->
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta charset="UTF-8" />
		<meta name="keywords" content="Edulearn Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design"
		/>

		<?php include('includes/head.php');?>
	</head>

	<body>
	<!-- header -->
	<?php include('includes/header1.php');?>
	<!-- //header -->

	<!-- banner -->
	<?php include('includes/navbar.php');?>
	<!-- breadcrumb -->
	<nav aria-label="breadcrumb">
		<ol class="breadcrumb">
			<li class="breadcrumb-item">
				<a href="index.php">Home</a>
			</li>
			<li class="breadcrumb-item active" aria-current="page">courses</li>
		</ol>
	</nav>
<!--// breadcrumb -->
<!-- //banner -->

<!-- course-->
	<!-- <div class="row cource-list-agile pt-4">
		<div class="col-lg-7 agile-course-main"> -->
			<div class="course-w3ls py-5">
				<div class="container py-xl-5 py-lg-3">
					<h3 class="title text-capitalize font-weight-light text-dark text-center mb-sm-5 mb-4">
						<span class="font-weight-bold">Courses</span>
					</h3>
					<div class="row cource-list-agile pt-4">
						<div class="col-lg-7 agile-course-main">
							<div class="w3ls-cource-first">
								<img src="images/1.png" alt="" class="img-fluid img-poiscour mx-auto d-block mt-2">
								<div class="px-md-5 px-4  pb-md-5 pb-4">
									<h3 class="text-dark">
										Vedic Maths
									</h3>
									<p class="mt-3 mb-4 pr-lg-5 text-justify" style="width: 98%;height: 160px; overflow: auto;">
										The “Vedic Mathematics” is called so because of its origin from Vedas. To be more specific, it has originated from “Atharvana Veda” the fourth Veda. “Atharvana Veda” deals with the branches like Engineering, Mathematics, sculpture, Medicine, and all other sciences. This wonderful and miracle method is re-introduced to the world by Swami Bharati Krisna Tirtha ji Mahaharaj, Shankaracharya of Goverdhan Peath. “Vedic Mathematics” was the name given by him. He was the person who collected lost formulae from the writings of “Atharwana Veda” and wrote them in the form of Sixteen Sutras and thirteen sub-sutras. Vedic Mathematics introduces the wonderful applications to Arithmetical computations, theory of numbers, compound multiplication, algebraic operations, factorizations, simple quadratic and higher order equations, simultaneous quadratic equations, partial fractions, calculus, squaring, cubing, square root, cube root , coordinate geometry and the wonderful Vedic Numerical code and so…on What is the importance of vedic maths in today’s world ? Mathematics is the body of knowledge centered on concepts such as quantity, structure, space, and change, and also the academic discipline which studies them. Vedic Maths is the basis for all modern concepts of maths so it is the backbone even in astrology and scientific calculations. Well, it gives you some short cut mantras to perform processes like long division, complex multiplication, finding square roots, cube roots, etc, etc. Vedic Maths is more than just a few shortcuts; it is actually another way of solving problems. U can actually get into deeper concepts like calculus using this. Ancient Mathematicians discovered the Pythagoras theorem and rudimentary calculus ages before the western world even thought of it. Mathematics is the body of knowledge centered on concepts such as quantity, structure, space, and change, and also the academic discipline which studies them. Vedic Maths is the basis for all modern concepts of maths so it is the backbone even in astrology and scientific calculations. Well, it gives you some short cut mantras to perform processes like long division, complex multiplication, finding square roots, cube roots, etc, etc. Vedic Maths is more than just a few shortcuts; it is actually another way of solving problems. It is actually an alternate way of solving the problem.
									</p>
								</div>
							</div>
						</div>
						<div class="col-lg-5 agile-course-main-2 mt-4">
							<img src="/home/sagar/Downloads/img4.jpg" alt="" class="img-fluid" style="height: 328px;">
						</div>
						<div class="buttons-w3ls">
							<a class="btn button-cour-w3ls text-white" href="course_details.html" role="button">	Learn More
							</a>
							<a class="btn bg-dark text-white" href="form.html" role="button">
								Apply Now
							</a>
						</div>
					</div>

					<div class="row cource-list-agile cource-list-agile-2">
						<div class="col-lg-5 agile-course-main-3 mt-4">
							<img src="images/am2.jpg" alt="" class="img-fluid" style="width: 95%;">
						</div>
						<div class="col-lg-7 agile-course-main text-right" >
							<div class="w3ls-cource-first">
								<img src="images/2.png" alt="" class="img-fluid img-poiscour mx-auto d-block mt-2" >
								<div class="px-md-5 px-4  pb-md-5 pb-4">
									<h3 class="text-dark">
										Hand writing
									</h3>
									<p class="mt-3 mb-4 pr-lg-5 text-justify" style="width: 98%;height: 160px; overflow: auto;">
										Handwriting Good handwriting has always been cherished by the young and the old alike. "One of the powerful ways of communication is writing. Students who don't master neat letter formation are often at a disadvantage, which can impact their grade." Advantages of good handwriting are reaped right from School to College and from there to the University stage. Answers to questions in examination halls and written assignments at every level of study presented in good handwriting take good appreciation as well as additional marks. And when students enter their employment resume, beautiful hand writing proves for them a sort of bonus because they will take notes at meetings and discussions with ease. Our innovative methods tempered with scientific touch for teaching Calligraphy, Handwriting Improvement and Speed Writing have been easily adopted by our students. Our emphasis is more on practice. Our technique of teaching handwriting improvement is useful equally for persons of every age. Their learning this art is guaranteed. It's ideal to have a distinctive style of handwriting of your own. If you pay continuous attention to improve your handwriting, you can have amazing result in the long run. You can improve your handwriting by specially taking care of how you write each alphabet. One alphabet in a word can turn the next alphabet beautiful or ugly. A creative way to improve your handwriting is to observe other's handwriting carefully, especially of those who have good handwriting. Observe how they write each alphabet and take remedial action on your side if required. Pay special attention to alphabets "y,g,f,j,p,q". In continuous writing, these alphabets plays an important role in making your handwriting look good. You can practice handwriting improvement from today itself. Write a paragraph daily and file it. Next day find a scope for improvement on that. You can also consult your friends or relatives on how better an alphabet can be written, so that it seamlessly integrates with the rest of the word. Initially practice on a rough surface and use pencil for writing. This is necessary to be in control when you are changing style. Once you possess good handwriting, people will start admire and respect you. It is a skill that can be cultivated with daily practice. There are numerous resources available on handwriting improvement. Handwriting analysis is now gaining more popularity. Many job interviews involve Handwriting analysis also. Handwriting analyst tries to interpret one's behavior through careful observation of handwriting. Your handwriting is unique like your fingerprints. Fingerprints identify your physical body. Handwriting reveals your whole personality - your mind, heart and soul. Graphology is the study and handwriting analysis to reveal personality traits. It is an art and a science, a branch of psychological studies. When a person writes, it is his hand that does the writing, but his brain that does the dictating. There have been many cases of amputees who, having lost the hand or arm with which they wrote, relearned the art with either the other hand, or the feet, or the mouth. Aside from a certain understandable shakiness caused by the difficulties of the feat, the writings were extremely similar to the originals. Trained graphologists had no trouble recognizing the same individual. From this, we see that it is the personality that is expressed on paper by the handwriting. When a person writes in a given fashion, it represents a particular personality trait, which comes directly from the brain. As a child you were taught to write. Why don't you continue to write the way you were taught? The fact that you don't is the reason graphology exists.... For example, when someone starts to write a letter, he must immediately decide where and how he should form it. In school, we were taught to start with a soft-curving loop and end the same way. As the writer matures, he usually drops them, different from what he was taught in school, because it does not facilitate the writing process. Hence, retaining them can reflect some immaturity, etc.
									</p>
								</div>
							</div>
						</div>
						<div class="buttons-w3ls-2">
							<a class="btn button-cour-w3ls text-white" href="course_details.html" role="button">	Learn More
							</a>
							<a class="btn bg-dark text-white" href="form.html" role="button">
								Apply Now
							</a>
						</div>
					</div>
					<div class="row cource-list-agile pt-4">
						<div class="col-lg-7 agile-course-main">
							<div class="w3ls-cource-first">
								<img src="images/1.png" alt="" class="img-fluid img-poiscour mx-auto d-block mt-2">
								<div class="px-md-5 px-4  pb-md-5 pb-4">
									<h3 class="text-dark">
										Abacus At School
									</h3>
									<p class="mt-3 mb-4 pr-lg-5 text-justify" style="width: 98%;height: 160px; overflow: auto;">
										ABACUS ACADEMY, The World’s highly reputed Abacus brand directly ties-up with reputed schools to promote quality-oriented Abacus training for students. We have been providing Abacus classes all around the Globe more than a decade. We provide the finest learning experience with unique study materials that helps to boost the mental calculation ability of students in its best proven way.Today, Abacus has been widely used in many schools as an external agent introduced to improve the accuracy and speed of mathematics calculations. Studies have shown that abacus not only increases the ability of children in performing mathematics calculations, but also develops the overall cognitive skills. Modules I : ABACUS PROPOSAL I WITH TEACHER (std. 1 to 6) ( Physical Mode Of Classes) 1) Students Needed – 100 minimums. 2) For Level 1 @ Rs. 350/- [1 level book (1 books), 1 abacus of 13 rod & 1 certificate]. 3) For Level 2 @ Rs. 550/- [2 levels books (4 books), 1 abacus of 13 rod & 2 certificate]. 4) We will be providing our teacher to teach students. 5) School should have to arrange classes for Abacus. 6) Student kits and other training materials will be provided. 7) Centralized online examinations and Certification. Modules II : ABACUS PROPOSAL II WITHOUT TEACHER (std. 1 to 6) ( Physical Mode Of Classes) 1) Students Needed – 100 minimums. 2) For Level 1 @ Rs. 200/- [1 level book (1 books), 1 abacus of 13 rod & 1 certificate]. 3) For Level 2 @ Rs. 350/- [2 levels books (4 books),1 abacus of 13 rod & 2 certificate]. 4) We will be giving training to your school teacher to teach students. 5) School should have to arrange classes for Abacus. 6) Student kits and other training materials will be provided. 7) Centralized online examinations and Certification. Abacus learning can be introduced to students as part of their school curriculum or as an after-school activity. It would help students to improve their concentration and memory power.It also enhances the child’s problem-solving ability. FOR DETAILS CONTACT :S.K. ACADEMY, # 78, NEW GADGEBABANAGAR, NEAR HANUMAN MANDIR, KHARBI ROAD,NAGPUR-440024 (MOBILE) : 8149897949; 8237372411; 8237372611 Email: shwetakids@gmail.com
									</p>
								</div>
							</div>
						</div>
						<div class="col-lg-5 agile-course-main-2 mt-4">
							<img src="images/am3.jpg" alt="" class="img-fluid">
						</div>
						<div class="buttons-w3ls">
							<a class="btn button-cour-w3ls text-white" href="course_details.html" role="button">	Learn More
							</a>
							<a class="btn bg-dark text-white" href="form.html" role="button">
								Apply Now
							</a>
						</div>
					</div>
					<div class="row cource-list-agile cource-list-agile-2">
						<div class="col-lg-5 agile-course-main-3 mt-4">
							<img src="images/am4.jpg" alt="" class="img-fluid" style="width: 95%;">
						</div>
						<div class="col-lg-7 agile-course-main text-right">
							<div class="w3ls-cource-first">
								<img src="images/2.png" alt="" class="img-fluid img-poiscour mx-auto d-block mt-2">
								<div class="px-md-5 px-4  pb-md-5 pb-4">
									<h3 class="text-dark">
										Montessori Teacher Training
									</h3>
									<p class="mt-3 mb-4 pr-lg-5 text-justify" style="width: 98%;height: 160px; overflow: auto;">
										SK Academy is the leading montessori teacher training institute offering montessori education for parents, teachers, school administrators & to all those who are interested in learning more about Dr.Maria Montessori’s methodology. The courseware has been designed by professional and experienced montessorians. The montessori course is comprehensive for the pre-school (3 to 6 years) level. Practical workshops consists of usage of Montessori materials and young child teaching techniques. Students get diploma in teacher training on successful completion of the course.
									</p>
								</div>
							</div>
						</div>
						<div class="buttons-w3ls-2">
							<a class="btn button-cour-w3ls text-white" href="course_details.html" role="button">	Learn More
							</a>
							<a class="btn bg-dark text-white" href="form.html" role="button">
								Apply Now
							</a>
						</div>
					</div>
					<!-- <div class="row cource-list-agile pt-4">
					<div class="col-lg-7 agile-course-main">
					<div class="w3ls-cource-first">
					<img src="images/1.png" alt="" class="img-fluid img-poiscour mx-auto d-block mt-2"></img>
					<div class="px-md-5 px-4  pb-md-5 pb-4">
					<h3 class="text-dark">Independent Study Korean</h3>
					<p class="mt-3 mb-4 pr-lg-5">accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore.</p>
					<ul class="list-unstyled text-capitalize">
					<li>
					<i class="fas fa-calendar-alt mr-3"></i>may - aug 2018</li>
					<li class="my-3">
					<i class="fas fa-clock mr-3"></i>4 - 6 hours</li>
					<li>
					<i class="fas fa-users mr-3"></i>70 seats</li>
					</ul>
					</div>
					</div>
					</div>
					<div class="col-lg-5 agile-course-main-2 mt-4">
					<img src="images/n2.jpg" alt="" class="img-fluid">
					</div>
					<div class="buttons-w3ls">
					<a class="btn button-cour-w3ls text-white" href="course_details.html" role="button">Learn More</a>
					<a class="btn bg-dark text-white" href="form.html" role="button">Apply Now</a>
					</div> -->
				</div>
					<!-- <div class="row cource-list-agile cource-list-agile-2">
					<div class="col-lg-5 agile-course-main-3 mt-4">
					<img src="images/n3.jpg" alt="" class="img-fluid">
					</div>
					<div class="col-lg-7 agile-course-main text-right">
					<div class="w3ls-cource-first">
					<img src="images/2.png" alt="" class="img-fluid img-poiscour mx-auto d-block mt-2"></img>
					<div class="px-md-5 px-4  pb-md-5 pb-4">
					<h3 class="text-dark">Intermediate Language Korean</h3>
					<p class="mt-3 mb-4 pl-lg-4">accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore.</p>
					<ul class="list-unstyled text-capitalize">
					<li>june - aug 2018
					<i class="fas fa-calendar-alt ml-3"></i>
					</li>
					<li class="my-3">3 - 6 hours
					<i class="fas fa-clock ml-3"></i>
					</li>
					<li>60 seats
					<i class="fas fa-users ml-3"></i>
					</li>
					</ul>
					</div>
					</div>
					</div>
					<div class="buttons-w3ls-2">
					<a class="btn button-cour-w3ls text-white" href="course_details.html" role="button">Learn More</a>
					<a class="btn bg-dark text-white" href="form.html" role="button">Apply Now</a>
					</div> -->
				</div>
			

		<?php include('includes/script.php')?>

		<?php include('includes/footer.php')?>
	</body>
</html>